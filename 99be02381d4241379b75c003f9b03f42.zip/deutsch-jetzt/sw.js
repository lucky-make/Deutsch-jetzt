/* sw.js — Deutsch Jetzt! service worker. Cache-first for app shell + data. */
const CACHE = 'deutsch-jetzt-v2';
const ASSETS = [
  './', './index.html', './css/style.css',
  './js/storage.js', './js/srs.js', './js/audio.js', './js/exercises.js', './js/app.js',
  './data/lessons.js', './data/lessons_2.js', './manifest.json', './icons/icon.svg'
];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request).then(cached => {
      const fetched = fetch(e.request).then(res => {
        if (res && res.status === 200 && res.type === 'basic') {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, copy));
        }
        return res;
      }).catch(() => cached);
      return cached || fetched;
    })
  );
});
